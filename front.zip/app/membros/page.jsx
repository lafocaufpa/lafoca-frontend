import PageMember from '@/components/pageMember/PageMember';

const MembersPage = () => {
  return (
    <>
      <PageMember/>
    </>
  );
};


export default MembersPage;