import TccsPage from '@/components/tccs/tccsPage';

const ProjectsPage = () => {
  return(
    <TccsPage/>
  );
};

export default ProjectsPage;