import LoginForm from '@/components/auth/login/LoginForm';

const Login = () => {
  return (
    <LoginForm/>
  );
};

export default Login;

