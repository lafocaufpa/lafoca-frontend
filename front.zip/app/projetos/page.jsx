import ViewPage from '@/components/viewer/ViewPage';

const ProjectsPage = () => {
  return(
    <ViewPage/>
  );
};

export default ProjectsPage;