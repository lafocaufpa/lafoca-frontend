import Cookies from '@/components/home/Footer/more/cookies/Cookies';

export default function PolicyCookiesPage() {
  return (
    <Cookies/>
  );
}