import ArticlesPage from '@/components/articles/ArticlesPage';

const ProjectsPage = () => {
  return(
    <ArticlesPage/>
  );
};

export default ProjectsPage;