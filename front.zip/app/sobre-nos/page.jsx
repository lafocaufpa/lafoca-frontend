import AboutUs from '@/components/home/Footer/more/aboutUs/AboutUs';

export default function AboutUsPage() {
  return (
    <AboutUs/>
  );
}